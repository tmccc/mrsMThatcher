#!/usr/bin/env python3
"""Deterministic historical-context replies backed only by canonical research packets."""
from __future__ import annotations

import argparse
import copy
import ctypes
import hashlib
import json
import os
import re
import stat
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlsplit

from remote_write_transport_journal import (
    BoundSourceReceiptTransitionError,
    LANE_SOURCE_VALIDATOR_ID,
    MAX_CONFIRMATION_EPOCH,
    MIN_CONFIRMATION_EPOCH,
    bind_confirmed_transport_source,
    canonical_json_bytes,
    journal_path_for_receipt,
    publish_exact_source_receipt_document,
    replace_bound_source_receipt,
    retire_confirmed_transport_transaction,
    transport_journal_is_blocking,
    verify_confirmed_transport_source_lineage,
)
from exact_receipt_retirement import (
    prepare_exact_receipt_retirement,
    retirement_auxiliary_barrier_exists,
    retire_or_resume_exact_receipt,
)
from transaction_mutation_authority import TransactionMutationAuthority

DEFAULT_RESEARCH_DIR = Path("semantic_alignment_research/quote_research_full_001")
DEFAULT_MAXIMUM_LENGTH = 4000
MAXIMUM_SUPPORTED_LENGTH = 25_000
MAXIMUM_TRANSACTION_RECEIPT_BYTES = 256 * 1024
_RECEIPT_NOT_PRELOADED = object()
_RENAME_EXCHANGE = 2
_RECEIPT_RETIREMENT_TOMBSTONE = (
    b"historical-context receipt retirement in progress\n"
)
VERIFICATION_LABELS = {
    "exact": "Exact wording",
    "normalised": "Normalised wording",
    "excerpt": "Verified excerpt",
    "variant": "Historically verified variant",
    "paraphrase": "Historical paraphrase",
    "composite": "Composite wording",
    "misattributed": "Commonly misattributed wording",
    "unverified": "Exact wording not verified",
}
SOURCE_PRIORITIES = (
    ("margaretthatcher.org", "Margaret Thatcher Foundation transcript"),
    ("hansard", "Hansard"),
    ("gov.uk", "Original speech transcript"),
    ("archive.org", "Thatcher-authored publication"),
)
QUOTATION_AGGREGATORS = (
    "allgreatquotes", "azquotes", "brainyquote", "goodreads", "libquotes",
    "magicalquote", "notable-quotes", "picturequotes", "quotefancy", "quotepark",
    "quotes.net", "quotetab", "quotery", "wikiquote", "wisesayings", "wonderfulquote",
)
URL_WEIGHT = 23
UNKNOWN_VALUES = {"", "n/a", "n.a.", "none", "not available", "unknown", "unavailable"}
HISTORICAL_CONTEXT_FORMATTER_V2 = "historical_context_reply_schema_v2"
HISTORICAL_CONTEXT_FORMATTER_V3 = "historical_context_reply_schema_v3"
HISTORICAL_CONTEXT_FORMATTER_V4 = "historical_context_reply_schema_v4"
HISTORICAL_CONTEXT_FORMATTER_V5 = "historical_context_reply_schema_v5"
PUBLIC_RENDERING_MODE = "public"
INTERNAL_RENDERING_MODE = "internal"
HISTORICAL_CONTEXT_RENDERING_MODES = frozenset({
    PUBLIC_RENDERING_MODE,
    INTERNAL_RENDERING_MODE,
})
_V2_UNCERTAIN_STATUSES = {"paraphrase", "composite", "misattributed", "unverified"}
_V2_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "been", "being", "but", "by", "for", "from",
    "had", "has", "have", "he", "her", "hers", "him", "his", "i", "if", "in", "into", "is",
    "it", "its", "not", "of", "on", "or", "our", "she", "that", "the", "their", "them", "there",
    "they", "this", "to", "was", "we", "were", "what", "when", "where", "which", "who", "will",
    "with", "would", "you", "your", "must", "should", "can", "could", "may", "than", "then",
}
_V2_MONTHS = {
    "january": "January", "february": "February", "march": "March", "april": "April",
    "may": "May", "june": "June", "july": "July", "august": "August",
    "september": "September", "october": "October", "november": "November", "december": "December",
}
_V2_DATE_LIKE_EVENT_TEXT = re.compile(
    r"(?:\b(?:18|19|20)\d{2}\b|"
    r"\b(?:0?[1-9]|[12]\d|3[01])(?:st|nd|rd|th)?\s+"
    r"(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|"
    r"Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|"
    r"Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\b|"
    r"\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|"
    r"Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|"
    r"Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+"
    r"(?:0?[1-9]|[12]\d|3[01])(?:st|nd|rd|th)?\b)",
    re.I,
)
_V2_DIAGNOSTIC_EVENT_SLASH = re.compile(r"\s*/\s*")
_V2_GENERIC_CONTEXT = (
    "The surviving attribution does not establish an occasion, date or "
    "immediate historical issue."
)
_FORMATTER_METADATA_KEYS_V2 = {
    "formatter_version", "template_variant", "meaning_included", "meaning_decision_reason",
    "raw_character_count", "weighted_character_count", "verification_label", "source_class",
    "historical_confidence", "shortening_applied",
}
_FORMATTER_METADATA_KEYS_V3 = _FORMATTER_METADATA_KEYS_V2 | {
    "confidence_dimensions", "source_role_audit_version",
}
_FORMATTER_METADATA_KEYS_V4 = _FORMATTER_METADATA_KEYS_V3 | {"rendering_mode"}
_FORMATTER_METADATA_KEYS_V5 = _FORMATTER_METADATA_KEYS_V4
_LEGACY_SOURCE_ROLE_AUDIT_VERSIONS = frozenset({
    "historical-context-source-roles-v1",
    "historical-context-source-roles-v2-recovered-citations",
    "historical-context-source-roles-v4-multi-provider-guarded-approximate-80",
    "historical-context-source-roles-v5-independent-review-and-exclusive-counts",
    "historical-context-source-roles-v7-curated-source-adjudications",
    "historical-context-source-roles-v8-claim-specific-public-context",
})
_MARGARET_THATCHER_CANONICAL_SPEAKER = "margaret thatcher"
THATCHER_ATTRIBUTION_RULE_VERSION = "canonical-principal-speaker-v2-reject-misattributed"


class AmbiguousContextReplyOutcome(RuntimeError):
    """A durable sending record exists, so repeating the reply could duplicate it."""

    def __init__(
        self,
        message: str,
        *,
        parent_post_id: str | None = None,
        reply_text: str | None = None,
    ):
        """Preserve the durable parent and reply payload for ambiguity evidence."""
        super().__init__(message)
        self.parent_post_id = parent_post_id
        self.reply_text = reply_text


class DefiniteContextReplyLocalPersistenceError(RuntimeError):
    """A proved non-success remains locally blocked by durable state."""

    def __init__(
        self,
        message: str,
        *,
        parent_post_id: str | None = None,
        reply_text: str | None = None,
        source_receipt_sha256: str | None = None,
        source_receipt_attempt_number: int | None = None,
        remote_error: BaseException | None = None,
    ):
        """Preserve diagnostic identity without claiming remote ambiguity."""

        super().__init__(message)
        self.parent_post_id = parent_post_id
        self.reply_text = reply_text
        self.source_receipt_sha256 = source_receipt_sha256
        self.source_receipt_attempt_number = source_receipt_attempt_number
        self.remote_error = remote_error


def utc_now() -> str:
    """Return the current UTC time as an ISO 8601 string."""
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def quote_text_hash(text: str) -> str:
    """Return whether quote text hash."""
    return hashlib.sha256(re.sub(r"\s+", " ", str(text or "").strip()).encode()).hexdigest()


def packet_is_attributed_to_margaret_thatcher(packet: dict[str, Any]) -> bool:
    """Accept only packets whose canonical principal speaker is Thatcher herself."""
    if not isinstance(packet, dict):
        return False
    verification = str(packet.get("verification_status") or "").strip().casefold()
    if verification == "misattributed":
        return False
    speaker = re.sub(r"\s+", " ", str(packet.get("speaker") or "").strip())
    principal = re.split(r"\s*(?:\(|/)\s*", speaker, maxsplit=1)[0].strip().casefold()
    return principal == _MARGARET_THATCHER_CANONICAL_SPEAKER


def atomic_write_json(path: Path, value: Any, *, durable: bool = True) -> None:
    """Write JSON atomically and optionally durably."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True); handle.write("\n")
            handle.flush()
            if durable: os.fsync(handle.fileno())
        os.replace(temporary, path)
        if durable:
            directory = os.open(path.parent, os.O_RDONLY)
            try: os.fsync(directory)
            finally: os.close(directory)
    except BaseException:
        try: os.unlink(temporary)
        except FileNotFoundError: pass
        raise


def durable_unlink(path: Path) -> None:
    """Perform the durable unlink operation."""
    path.unlink()
    directory = os.open(path.parent, os.O_RDONLY)
    try: os.fsync(directory)
    finally: os.close(directory)


def _rename_exchange_at(
    directory_fd: int,
    left_basename: str,
    right_basename: str,
) -> None:
    """Atomically exchange two direct children or fail before changing either."""

    libc = ctypes.CDLL(None, use_errno=True)
    renameat2 = getattr(libc, "renameat2", None)
    if renameat2 is None:
        raise RuntimeError(
            "atomic historical-context receipt retirement is unavailable"
        )
    renameat2.argtypes = (
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_char_p,
        ctypes.c_uint,
    )
    renameat2.restype = ctypes.c_int
    result = renameat2(
        directory_fd,
        os.fsencode(left_basename),
        directory_fd,
        os.fsencode(right_basename),
        _RENAME_EXCHANGE,
    )
    if result != 0:
        error_number = ctypes.get_errno()
        raise OSError(error_number, os.strerror(error_number))


def load_and_validate_corpus_core(
    research_dir: Path = DEFAULT_RESEARCH_DIR,
) -> tuple[dict[str, Any], set[str]]:
    """Load and validate the canonical packet/manifest/status partition."""
    from semantic_alignment.quote_research_schema import TOP_LEVEL_FIELDS, validate_packet

    packets_path = research_dir / "research_packets.json"
    packets_bytes = packets_path.read_bytes()
    packets_document = json.loads(packets_bytes)
    manifest_document = json.loads((research_dir / "corpus_manifest.json").read_text())
    status = json.loads((research_dir / "final_unresolved" / "final_research_status.json").read_text())
    if not all(isinstance(value, dict) for value in (packets_document, manifest_document, status)):
        raise RuntimeError("quotation research corpus documents must be JSON objects")
    packets = packets_document.get("items")
    records = manifest_document.get("records")
    declared_total = manifest_document.get("record_count")
    if (
        type(declared_total) is not int
        or declared_total <= 0
        or not isinstance(records, list)
        or len(records) != declared_total
        or any(
            not isinstance(record, dict)
            or not re.fullmatch(r"[0-9a-f]{64}", str(record.get("quote_id") or ""))
            for record in records
        )
        or len({record["quote_id"] for record in records}) != declared_total
    ):
        raise RuntimeError("quotation research manifest does not match its declared unique record count")
    manifest = {record["quote_id"]: record for record in records}
    unresolved_records = status.get("unresolved_quote_ids")
    declared_completed = status.get("completed_quotes")
    declared_unresolved = status.get("unresolved_quotes")
    status_total = status.get("total_manifest_quotes")
    if (
        type(declared_completed) is not int
        or declared_completed < 0
        or type(declared_unresolved) is not int
        or declared_unresolved < 0
        or type(status_total) is not int
        or status_total != declared_total
        or declared_completed + declared_unresolved != declared_total
        or not isinstance(unresolved_records, list)
        or len(unresolved_records) != declared_unresolved
        or len(set(unresolved_records)) != declared_unresolved
        or any(not re.fullmatch(r"[0-9a-f]{64}", str(quote_id or "")) for quote_id in unresolved_records)
    ):
        raise RuntimeError("quotation research status counts or unresolved quote IDs are inconsistent")
    unresolved = set(unresolved_records)
    if not isinstance(packets, dict) or len(packets) != declared_completed:
        raise RuntimeError("completed quotation packet count does not match research status")
    if status.get("corpus_hash") != hashlib.sha256(packets_bytes).hexdigest():
        raise RuntimeError("completed quotation packet file hash does not match research status")
    if len(manifest) != declared_total or set(manifest) != set(packets) | unresolved:
        raise RuntimeError("canonical quotation manifest does not partition into completed and unresolved records")
    if set(packets) & unresolved:
        raise RuntimeError("unresolved quote appears in completed packet collection")
    for quote_id, packet in packets.items():
        if (
            not isinstance(packet, dict)
            or packet.get("quote_id") != quote_id
            or not isinstance(packet.get("quote_text"), str)
            or hashlib.sha256(packet["quote_text"].encode("utf-8")).hexdigest()
            != quote_id
            or packet.get("quote_text") != manifest[quote_id].get("quote_text")
        ):
            raise RuntimeError(f"canonical quote identity mismatch: {quote_id}")
        try: validate_packet({field: packet[field] for field in TOP_LEVEL_FIELDS}, {"quote_id": quote_id, "quote_text": packet["quote_text"]})
        except (KeyError, ValueError) as exc: raise RuntimeError(f"completed packet is not schema-valid: {quote_id}: {exc}") from exc
        if packet.get("verification_status") not in VERIFICATION_LABELS:
            raise RuntimeError(f"unsupported verification status: {quote_id}")
    return packets, unresolved


def load_and_validate_corpus(
    research_dir: Path = DEFAULT_RESEARCH_DIR,
    *,
    require_source_role_audit: bool = False,
    load_source_role_audit: bool = True,
    expected_packet_corrections_sha256: str | None = None,
    require_packet_corrections_hash_binding: bool = False,
) -> tuple[dict[str, Any], set[str]]:
    """Load the canonical corpus and attach validated context-only sidecars."""
    packets, unresolved = load_and_validate_corpus_core(research_dir)
    from historical_context_source_roles import validate_and_attach_audit

    eligible_ids = {
        quote_id for quote_id, packet in packets.items()
        if packet_is_attributed_to_margaret_thatcher(packet)
    }
    if load_source_role_audit:
        packets = validate_and_attach_audit(
            packets,
            unresolved,
            research_dir=research_dir,
            attribution_eligible_ids=eligible_ids,
            required=require_source_role_audit,
        )
    elif require_source_role_audit:
        raise ValueError("required source-role audit cannot be skipped")

    # Keep the canonical provider-research packets immutable while allowing a
    # narrowly validated editorial correction to affect future rendering.
    from historical_context_packet_corrections import (
        PACKET_CORRECTIONS_FILENAME,
        apply_packet_corrections,
    )
    from historical_context_source_curated_evidence import (
        CURATED_EVIDENCE_FILENAME,
    )

    corrections_path = research_dir / PACKET_CORRECTIONS_FILENAME
    try:
        corrections_bytes = corrections_path.read_bytes()
    except FileNotFoundError:
        corrections_bytes = None
    if (
        require_packet_corrections_hash_binding
        and corrections_bytes is not None
        and expected_packet_corrections_sha256 is None
    ):
        raise RuntimeError(
            "historical-context packet corrections lack an authoritative "
            "SHA-256 declaration"
        )
    if expected_packet_corrections_sha256 is not None:
        if not re.fullmatch(
            r"[0-9a-f]{64}", str(expected_packet_corrections_sha256)
        ):
            raise RuntimeError(
                "historical-context packet correction expected SHA-256 is invalid"
            )
        if corrections_bytes is None:
            raise RuntimeError(
                "required historical-context packet corrections are missing"
            )
        if (
            hashlib.sha256(corrections_bytes).hexdigest()
            != expected_packet_corrections_sha256
        ):
            raise RuntimeError(
                "historical-context packet correction SHA-256 differs"
            )
    if corrections_bytes is not None:
        curated_path = research_dir / CURATED_EVIDENCE_FILENAME
        if not curated_path.exists():
            raise RuntimeError(
                "historical-context packet corrections lack curated evidence"
            )
        corrections = json.loads(corrections_bytes)
        curated_evidence = json.loads(curated_path.read_text(encoding="utf-8"))
        if not isinstance(corrections, dict) or not isinstance(
            curated_evidence, dict
        ):
            raise RuntimeError(
                "historical-context packet correction documents must be JSON objects"
            )
        packets = apply_packet_corrections(
            corrections,
            packets,
            curated_evidence,
        )
    return packets, unresolved


def packet_for_posted_quote(packets: dict[str, Any], unresolved: set[str], quote_hash: str,
                            quote_text: str) -> dict[str, Any] | None:
    """Resolve bot-normalized quote identity without changing canonical IDs or wording."""
    if quote_hash in unresolved: return None
    direct = packets.get(quote_hash)
    if direct is not None:
        return direct if (
            packet_is_attributed_to_margaret_thatcher(direct)
            and re.sub(r"\s+", " ", direct["quote_text"].strip()) == re.sub(r"\s+", " ", quote_text.strip())
        ) else None
    normalised = re.sub(r"\s+", " ", quote_text.strip())
    matches = [
        packet for packet in packets.values()
        if packet_is_attributed_to_margaret_thatcher(packet)
        and re.sub(r"\s+", " ", packet["quote_text"].strip()) == normalised
    ]
    return matches[0] if len(matches) == 1 else None


def _source_rank(source: dict[str, Any]) -> tuple[int, int, str]:
    title = str(source.get("title") or "").lower(); url = str(source.get("url") or "")
    host = urlsplit(url).netloc.lower(); text = f"{title} {host} {source.get('source_type','')}"
    for index, (marker, _description) in enumerate(SOURCE_PRIORITIES):
        if marker in text: return index, len(url), url
    if any(word in text for word in ("speech", "transcript", "statement")): return 2, len(url), url
    if any(word in text for word in ("memoir", "book", "publication")): return 3, len(url), url
    if any(word in text for word in ("interview", "bbc", "newspaper", "times", "guardian")): return 4, len(url), url
    return 5, len(url), url


def _locator_rank(locator: str) -> int:
    text = locator.lower()
    if "margaret thatcher foundation" in text:
        return 0
    if "hansard" in text:
        return 1
    if any(word in text for word in ("archive", "document", "speech", "statement", "transcript")):
        return 2
    if any(word in text for word in ("book", "memoir", "statecraft", "downing street years", "path to power")):
        return 3
    return 6


def _is_grounding_redirect(url: str) -> bool:
    parsed = urlsplit(url)
    return (
        parsed.netloc.lower() == "vertexaisearch.cloud.google.com"
        and parsed.path.startswith("/grounding-api-redirect/")
    )


def select_primary_source(packet: dict[str, Any]) -> dict[str, str] | None:
    """Select the strongest source record from a research packet."""
    if isinstance(packet.get("_source_role_audit"), dict):
        from historical_context_source_roles import public_sources

        sources = public_sources(packet)
        if not sources:
            return {
                "title": "No reliable source located",
                "url": "",
                "source_type": "unavailable",
            }
        role_priority = {
            "wording_verification": 0,
            "attribution_support": 1,
            "source_event_support": 2,
            "historical_context_support": 3,
        }
        source = min(
            sources,
            key=lambda row: min(
                (role_priority.get(role, 9) for role in row.get("roles", [])),
                default=9,
            ),
        )
        return {
            "title": source["title"],
            "url": source["url"],
            "source_type": source["source_type"],
        }
    locator = " ".join(str(packet.get("stable_locator") or "").split())
    valid_locator = locator if locator.lower() not in UNKNOWN_VALUES else ""
    all_sources = [source for source in packet.get("sources", []) if isinstance(source, dict)
               and str(source.get("title") or "").strip()
               and str(source.get("url") or "").startswith(("https://", "http://"))]
    eligible_sources = [
        source for source in all_sources
        if not any(
            marker in f"{source.get('title', '')} {source.get('url', '')}".lower()
            for marker in QUOTATION_AGGREGATORS
        )
    ]
    sources = [
        source for source in eligible_sources
        if not _is_grounding_redirect(str(source.get("url") or ""))
    ]
    if not sources:
        if valid_locator:
            return {"title": valid_locator, "url": "", "source_type": "canonical_stable_locator"}
        if eligible_sources:
            source = min(eligible_sources, key=_source_rank)
            title = " ".join(str(source["title"]).split())
            if packet.get("verification_status") in {"unverified", "misattributed"}:
                title = "Attribution record: " + title
            return {
                "title": title,
                "url": "",
                "source_type": "grounded_source_title_without_public_url",
            }
        if packet.get("verification_status") in {"unverified", "misattributed"} and all_sources:
            source = min(all_sources, key=_source_rank)
            source_url = str(source["url"]).strip()
            return {"title": "Attribution record: " + " ".join(str(source["title"]).split()),
                    "url": "" if _is_grounding_redirect(source_url) else source_url,
                    "source_type": "attribution_error_documentation"}
        return None
    source = min(sources, key=_source_rank)
    if valid_locator and _locator_rank(valid_locator) < _source_rank(source)[0]:
        return {"title": valid_locator, "url": "", "source_type": "canonical_stable_locator"}
    return {"title": " ".join(str(source["title"]).split()), "url": str(source["url"]).strip(),
            "source_type": str(source.get("source_type") or "unknown")}


def classify_source(source: dict[str, Any] | None) -> str:
    """Map a selected canonical source to a stable, non-provider digest class."""
    if not source:
        return "unavailable"
    title = str(source.get("title") or "").lower()
    url = str(source.get("url") or "")
    source_type = str(source.get("source_type") or "").lower()
    host = urlsplit(url).netloc.lower()
    text = f"{title} {host} {source_type}"
    if "margaretthatcher.org" in text or "margaret thatcher foundation" in text:
        return "Margaret Thatcher Foundation"
    if "hansard" in text:
        return "Hansard"
    if any(term in text for term in ("thatcher-authored", "memoir", "book", "publication")):
        return "Thatcher-authored publication"
    if any(term in text for term in ("interview", "bbc", "newspaper", "the times", "guardian")):
        return "contemporary interview"
    if any(term in text for term in ("conservative", "conservatives.com", "conservative party")):
        return "official Conservative publication"
    if source_type == "canonical_stable_locator":
        return "canonical locator only"
    if not url or _is_grounding_redirect(url):
        return "no public URL"
    if any(term in text for term in ("speech", "transcript", "statement", "gov.uk")):
        return "original speech transcript"
    return "other authoritative source"


def _sentence(value: Any) -> str:
    text = " ".join(str(value or "").split()).strip()
    if text.lower() in UNKNOWN_VALUES: return ""
    return text if text.endswith((".", "?", "!")) else text + "."


def _first_sentence(*values: Any) -> str:
    for value in values:
        sentence = _sentence(value)
        if sentence:
            return sentence
    return ""


def _shorten_words(text: str, maximum: int) -> str:
    if maximum <= 0: return ""
    if len(text) <= maximum: return text
    if maximum < 2: return ""
    shortened = text[: maximum - 1].rsplit(" ", 1)[0].rstrip(" ,;:-")
    return shortened + "…" if shortened else ""


def _has_forbidden_style(text: str) -> bool:
    emoji = re.compile("[\U0001F000-\U0001FAFF\u2600-\u27BF]")
    return bool(re.search(r"(?:^|\s)#[A-Za-z0-9_]", text) or emoji.search(text))


def x_weighted_length(text: str) -> int:
    """Calculate X weighted text length."""
    urls = re.findall(r"https?://\S+", text)
    return len(text) - sum(len(url) for url in urls) + URL_WEIGHT * len(urls)


def format_context_reply(packet: dict[str, Any], *, maximum_length: int = DEFAULT_MAXIMUM_LENGTH,
                         include_meaning: bool = True, include_source: bool = True,
                         include_verification: bool = True) -> dict[str, Any] | None:
    """Format a source-grounded historical context reply."""
    if type(maximum_length) is not int or not 120 <= maximum_length <= MAXIMUM_SUPPORTED_LENGTH:
        raise ValueError(f"maximum_length must be from 120 to {MAXIMUM_SUPPORTED_LENGTH}")
    source = select_primary_source(packet) if include_source else None
    if include_source and source is None: return None
    event = _sentence(packet.get("source_event")) or "Source event not established."
    raw_date = " ".join(str(packet.get("date") or "").split()).strip()
    date = "Unknown" if raw_date.lower() in UNKNOWN_VALUES else raw_date
    immediate = _first_sentence(packet.get("immediate_subject"), packet.get("historical_context"))
    meaning = _first_sentence(packet.get("intended_argument"), packet.get("literal_meaning")) if include_meaning else ""
    verification = VERIFICATION_LABELS[packet["verification_status"]]
    event_label = (
        "Occasion"
        if packet["verification_status"] in {"exact", "normalised", "excerpt", "variant"}
        else "Source event"
    )

    def render(current_meaning: str, current_context: str, current_event: str, current_title: str) -> str:
        context_lines = ["Historical context", f"{event_label}: {current_event}", f"Date: {date}"]
        if current_context: context_lines.append(f"Immediate context: {current_context}")
        sections = ["\n".join(context_lines)]
        if current_meaning: sections.append(f"Meaning: {current_meaning}")
        provenance = []
        if include_verification: provenance.append(f"Verification: {verification}")
        if source: provenance.append(f"Source: {current_title}" + (f"\n{source['url']}" if source["url"] else ""))
        if provenance: sections.append("\n".join(provenance))
        return "\n\n".join(sections)

    source_title = source["title"] if source else ""
    original_meaning = meaning
    original_immediate = immediate
    original_event = event
    original_source_title = source_title
    text = render(meaning, immediate, event, source_title)
    # Meaning is always compressed or removed before any provenance field.
    if x_weighted_length(text) > maximum_length and meaning:
        fixed = x_weighted_length(render("", immediate, event, source_title))
        meaning = _shorten_words(meaning, maximum_length - fixed - len("\n\nMeaning: "))
        text = render(meaning, immediate, event, source_title)
    if x_weighted_length(text) > maximum_length:
        meaning = ""; text = render("", immediate, event, source_title)
    if x_weighted_length(text) > maximum_length and immediate:
        excess = x_weighted_length(text) - maximum_length
        immediate = _shorten_words(immediate, max(0, len(immediate) - excess))
        text = render("", immediate, event, source_title)
    if x_weighted_length(text) > maximum_length:
        excess = x_weighted_length(text) - maximum_length
        event = _shorten_words(event, max(12, len(event) - excess))
        text = render("", immediate, event, source_title)
    if x_weighted_length(text) > maximum_length and source:
        excess = x_weighted_length(text) - maximum_length
        source_title = _shorten_words(source_title, max(8, len(source_title) - excess))
        text = render("", immediate, event, source_title)
    weighted = x_weighted_length(text)
    if weighted > maximum_length or _has_forbidden_style(text): return None
    shortened = any((meaning != original_meaning, immediate != original_immediate,
                     event != original_event, source_title != original_source_title))
    return {"text": text, "character_count": weighted, "raw_character_count": len(text), "maximum_length": maximum_length,
            "verification_label": verification if include_verification else None, "source": source,
            "source_class": classify_source(source),
            "historical_confidence": packet.get("research_confidence") or "unavailable",
            "shortening_applied": shortened,
            "meaning_included": bool(meaning),
            "meaning_omitted": not bool(meaning),
            "source_omitted": not bool(source),
            "verification_omitted": not include_verification,
            "quote_id": packet["quote_id"]}


def _v2_clean(value: Any) -> str:
    text = " ".join(str(value or "").split()).strip()
    return "" if text.lower() in UNKNOWN_VALUES else text


def _v2_one_sentence(value: Any) -> str:
    text = _v2_clean(value)
    if not text:
        return ""
    match = re.match(r"(.+?[.!?])(?:\s|$)", text)
    sentence = match.group(1) if match else text
    return sentence if sentence.endswith((".", "?", "!")) else sentence + "."


def _v2_british_dates_in_text(value: str) -> str:
    pattern = re.compile(
        r"\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+"
        r"(\d{1,2}),\s*(\d{4})\b",
        re.I,
    )
    return pattern.sub(
        lambda match: f"{int(match.group(2))} {_V2_MONTHS[match.group(1).lower()]} {match.group(3)}",
        value,
    )


def _v2_british_date(value: Any) -> str:
    text = _v2_clean(value)
    if not text:
        return ""
    published = re.fullmatch(r"unknown\s*\(published\s+(\d{4})\)", text, re.I)
    if published:
        return f"published in {published.group(1)}"
    decade = re.fullmatch(r"(\d{4}s)\s*\(exact date unknown\)", text, re.I)
    if decade:
        return decade.group(1)
    iso = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", text)
    if iso:
        year, month, day = iso.groups()
        names = tuple(_V2_MONTHS.values())
        if 1 <= int(month) <= 12 and 1 <= int(day) <= 31:
            return f"{int(day)} {names[int(month)-1]} {year}"
    american = re.fullmatch(r"([A-Za-z]+)\s+(\d{1,2}),\s*(\d{4})", text)
    if american and american.group(1).lower() in _V2_MONTHS:
        return f"{int(american.group(2))} {_V2_MONTHS[american.group(1).lower()]} {american.group(3)}"
    british = re.fullmatch(r"(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})", text)
    if british and british.group(2).lower() in _V2_MONTHS:
        return f"{int(british.group(1))} {_V2_MONTHS[british.group(2).lower()]} {british.group(3)}"
    return text if re.fullmatch(r"\d{4}", text) else _v2_british_dates_in_text(text)


def _v2_tokens(value: Any) -> set[str]:
    return {
        word for word in re.findall(r"[a-z0-9]+", _v2_clean(value).lower())
        if len(word) > 2 and word not in _V2_STOPWORDS
    }


def _v2_overlap(left: Any, right: Any) -> dict[str, float]:
    a, b = _v2_tokens(left), _v2_tokens(right)
    intersection = len(a & b)
    return {
        "jaccard": round(intersection / len(a | b), 4) if a | b else 0.0,
        "left_coverage": round(intersection / len(a), 4) if a else 0.0,
        "right_coverage": round(intersection / len(b), 4) if b else 0.0,
    }


def _v2_distinct_count(value: Any, *against: Any) -> int:
    used: set[str] = set()
    for item in against:
        used |= _v2_tokens(item)
    return len(_v2_tokens(value) - used)


def _v2_meaning_decision(packet: dict[str, Any], context: str) -> dict[str, Any]:
    meaning = _v2_one_sentence(packet.get("intended_argument")) or _v2_one_sentence(packet.get("literal_meaning"))
    quote = packet["quote_text"]
    mechanism = _v2_clean(packet.get("mechanism"))
    consequence = _v2_clean(packet.get("claimed_consequence"))
    quote_overlap = _v2_overlap(meaning, quote)
    context_overlap = _v2_overlap(meaning, context)
    mechanism_distinct = _v2_distinct_count(mechanism, quote, context, meaning)
    consequence_distinct = _v2_distinct_count(consequence, quote, context, meaning)
    obscure_reference = bool(re.search(
        r"\b(?:this|that|these|those|here|there|he|she|they|them|it|such|former|latter)\b",
        quote.lower(),
    ))
    counter_intuitive = bool(re.search(
        r"\b(?:paradox|contrary|although|despite|not .* but|rather than|unless|only if)\b",
        " ".join((quote, meaning, mechanism)).lower(),
    ))
    uncertain = packet.get("verification_status") in _V2_UNCERTAIN_STATUSES
    explicit_ambiguity = bool(packet.get("unresolved_questions")) or bool(_v2_clean(packet.get("text_variation_notes")))
    rhetorical_wrapper = meaning.lower().startswith((
        "that ", "to argue that ", "to assert that ", "to emphasise that ", "to emphasize that ",
        "to demonstrate that ", "to highlight that ",
    ))
    quote_states_mechanism = bool(re.search(
        r"\b(?:because|by|if|then|means?|results?|so that|cannot|requires?|depends?|leads?|creates?|"
        r"destroys?|without|when|where|better than|worse than)\b", quote, re.I,
    ))
    redundant_direct_proposition = (
        rhetorical_wrapper and not obscure_reference and "?" not in quote
        and (quote_states_mechanism or quote_overlap["left_coverage"] >= 0.35)
    )
    rule_outputs = {
        "meaning_quote_overlap": quote_overlap,
        "meaning_context_overlap": context_overlap,
        "mechanism_distinct_token_count": mechanism_distinct,
        "consequence_distinct_token_count": consequence_distinct,
        "obscure_reference_marker": obscure_reference,
        "counter_intuitive_marker": counter_intuitive,
        "uncertain_wording": uncertain,
        "explicit_ambiguity": explicit_ambiguity,
        "rhetorical_wrapper": rhetorical_wrapper,
        "quote_states_mechanism": quote_states_mechanism,
        "redundant_direct_proposition": redundant_direct_proposition,
    }
    if not meaning:
        included, reason = False, "No usable intended-argument or literal-meaning field."
    elif uncertain:
        included, reason = True, "Meaning retained because the wording is non-exact or uncertain."
    elif obscure_reference:
        included, reason = True, "Meaning retained because the quotation contains a context-dependent reference."
    elif counter_intuitive:
        included, reason = True, "Meaning retained because the argument is counter-intuitive or contrastive."
    elif redundant_direct_proposition:
        included, reason = False, "Meaning omitted because it restates a direct, self-contained proposition whose mechanism or substantive terms are already visible."
    elif mechanism_distinct >= 3:
        included, reason = True, "Meaning retained because the packet records a distinct explanatory mechanism."
    elif consequence_distinct >= 3:
        included, reason = True, "Meaning retained because the packet records a distinct claimed consequence."
    elif explicit_ambiguity and quote_overlap["right_coverage"] < 0.80:
        included, reason = True, "Meaning retained because the packet records ambiguity not resolved by the quotation alone."
    elif max(quote_overlap["left_coverage"], context_overlap["left_coverage"]) >= 0.78:
        included, reason = False, "Meaning omitted because its substantive terms are already present in the quotation or Context."
    else:
        included, reason = True, "Meaning retained because it adds substantive terms not supplied by the quotation or Context."
    return {"meaning": meaning, "meaning_included": included,
            "meaning_decision_reason": reason, "rule_outputs": rule_outputs}


def _v2_context_sentence(
    packet: dict[str, Any],
    supported_fields: set[str] | None = None,
    *,
    public_rendering: bool = False,
) -> str:
    event = _v2_clean(packet.get("source_event")) if (
        supported_fields is None or "source_event" in supported_fields
    ) else ""
    uncertain_event = re.fullmatch(r"unknown\s*\((.+)\)", event, re.I)
    if uncertain_event:
        qualifier = uncertain_event.group(1).strip()
        event = "" if qualifier.lower() == "attributed" else qualifier[0].upper() + qualifier[1:]
    elif re.match(r"unknown\s+", event, re.I):
        remainder = re.sub(r"^unknown\s+", "", event, flags=re.I).strip()
        event = f"Attributed to a {remainder}" if remainder else ""
    unsafe_public_event = bool(
        public_rendering
        and event
        and supported_fields is not None
        and "source_event" in supported_fields
        and "date" not in supported_fields
        and (
            _V2_DATE_LIKE_EVENT_TEXT.search(event)
            or _V2_DIAGNOSTIC_EVENT_SLASH.search(event)
        )
    )
    if unsafe_public_event:
        # Stripping pieces from a composite evidence label would guess which
        # surviving fragment is authoritative.  Use a neutral public fallback
        # while retaining the complete event in the internal rendering.
        event = ""
    event = _v2_british_dates_in_text(event).rstrip(". :;-")
    date = _v2_british_date(packet.get("date")) if (
        supported_fields is None or "date" in supported_fields
    ) else ""
    immediate = ""
    if supported_fields is None or "historical_context" in supported_fields:
        immediate = _v2_one_sentence(packet.get("immediate_subject")) or _v2_one_sentence(packet.get("historical_context"))
    immediate = _v2_british_dates_in_text(immediate.rstrip("."))
    if event and immediate and date: return f"{event}, {date}: {immediate}."
    if event and immediate: return f"{event}: {immediate}."
    if immediate and date: return f"{date}: {immediate}."
    if immediate: return immediate if immediate.endswith((".", "?", "!")) else immediate + "."
    if event and date: return f"{event}, {date}."
    if event: return event if event.endswith((".", "?", "!")) else event + "."
    if unsafe_public_event:
        return "The surviving record identifies an occasion, but does not establish a reliable date."
    if date: return f"The surviving record dates this wording to {date}, but does not establish its occasion."
    return _V2_GENERIC_CONTEXT


def _audited_public_sources(packet: dict[str, Any]) -> list[dict[str, Any]]:
    if not isinstance(packet.get("_source_role_audit"), dict):
        source = select_primary_source(packet)
        return [] if not source else [{**source, "roles": [], "claims_supported": []}]
    from historical_context_source_roles import public_sources

    return public_sources(packet)


def _audited_internal_sources(packet: dict[str, Any]) -> list[dict[str, Any]]:
    if not isinstance(packet.get("_source_role_audit"), dict):
        source = select_primary_source(packet)
        return [] if not source else [{**source, "roles": [], "claims_supported": []}]
    from historical_context_source_roles import internal_sources

    return internal_sources(packet)


_INTERNAL_SOURCE_COLLECTIONS = (
    "sources",
    "recovered_sources",
    "researched_sources",
    "curated_sources",
    "virtual_locator_sources",
    "model_proposed_source_leads",
    "renderable_sources",
)


def _internal_source_audit_payload(packet: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    """Return lossless source records and public-deduplication diagnostics."""
    audit = packet.get("_source_role_audit")
    if not isinstance(audit, dict):
        return {}, {"records": [], "groups": [], "identity_ambiguities": []}
    from historical_context_source_roles import public_source_identity_diagnostics

    collections = {
        name: copy.deepcopy(audit.get(name, []))
        for name in _INTERNAL_SOURCE_COLLECTIONS
    }
    return collections, public_source_identity_diagnostics(packet)


def _audited_verification_label(packet: dict[str, Any]) -> str:
    audit = packet.get("_source_role_audit")
    if isinstance(audit, dict):
        value = _v2_clean(audit.get("public_verification_wording"))
        if value:
            return value
    return VERIFICATION_LABELS[packet["verification_status"]]


def _public_verification_label(
    packet: dict[str, Any], confidence_dimensions: dict[str, str],
    sources: list[dict[str, Any]],
) -> str:
    """Return a concise public label without flattening the audited evidence."""
    audited = _audited_verification_label(packet)
    if audited == "Exact wording verified":
        return audited
    if audited in {"Historically verified variant", "Normalised wording verified"}:
        return "Historically verified variant"
    if audited == "Verified excerpt":
        return audited
    source_supports_attribution = any(
        "attribution" in source.get("claims_supported", []) for source in sources
    )
    if source_supports_attribution or confidence_dimensions["attribution"] in {"high", "medium"}:
        return "Attributed, but exact wording not independently verified"
    return "Research incomplete"


def _audited_confidence(packet: dict[str, Any]) -> dict[str, str]:
    audit = packet.get("_source_role_audit")
    if isinstance(audit, dict) and isinstance(audit.get("confidence_after"), dict):
        dimensions = audit["confidence_after"]
        required = {
            "attribution", "wording", "source_event", "date",
            "historical_context", "interpretation",
        }
        if set(dimensions) == required and all(
            value in {"high", "medium", "low", "unknown"}
            for value in dimensions.values()
        ):
            return dict(dimensions)
    fallback = str(packet.get("research_confidence") or "unknown")
    if fallback not in {"high", "medium", "low"}:
        fallback = "unknown"
    return {field: fallback for field in (
        "attribution", "wording", "source_event", "date",
        "historical_context", "interpretation",
    )}


def _conservative_historical_confidence(dimensions: dict[str, str]) -> str:
    ranking = {"unknown": 0, "low": 1, "medium": 2, "high": 3}
    score = min(ranking[dimensions["attribution"]], ranking[dimensions["wording"]])
    return {0: "low", 1: "low", 2: "medium", 3: "high"}[score]


def _public_source_lines(sources: list[dict[str, Any]]) -> list[str]:
    if not sources:
        return ["Source — No reliable source located"]
    lines: list[str] = []
    for source in sources:
        title = _v2_british_dates_in_text(_v2_clean(source.get("title"))).strip()
        if not title:
            continue
        line = f"Source — {title}"
        if source.get("url"):
            line += f"\n{source['url']}"
        lines.append(line)
    return lines or ["Source — No reliable source located"]


def _internal_source_lines(sources: list[dict[str, Any]]) -> list[str]:
    if not sources:
        return ["Source — No reliable source located"]
    labels = {
        "wording": "wording",
        "attribution": "attribution",
        "source_event": "source event",
        "date": "date",
        "historical_context": "historical context",
    }
    lines: list[str] = []
    for source in sources:
        supported = [labels[field] for field in labels if field in source.get("claims_supported", [])]
        role_label = ", ".join(supported) or "role-scoped evidence"
        prefix = "Secondary recollection" if source.get("secondary_recollection") else "Source"
        line = f"{prefix} ({role_label}) — {source['title']}"
        if source.get("url"):
            line += f"\n{source['url']}"
        lines.append(line)
    return lines


def _v2_forbidden_style(text: str) -> bool:
    return bool(
        re.search(r"(?:^|\s)#[A-Za-z0-9_]", text)
        or re.search("[\U0001F000-\U0001FAFF\u2600-\u27BF]", text)
        or "vertexaisearch.cloud.google.com/grounding-api-redirect/" in text
        or re.search(r"(?:^|[—:\s])(N/A|None|unavailable)(?:$|[.\s])", text, re.I)
        or re.search(r"\b(?:did you know|interesting fact|click here|learn more)\b", text, re.I)
    )


def _format_context_reply_v2_legacy(
    packet: dict[str, Any],
    *,
    maximum_length: int,
    include_meaning: bool,
    include_source: bool,
    include_verification: bool,
) -> dict[str, Any] | None:
    """Reproduce schema-v2 output for frozen unaudited research tooling."""
    source = select_primary_source(packet) if include_source else None
    if include_source and (not source or not _v2_clean(source.get("title"))):
        return None
    context = _v2_context_sentence(packet)
    decision = _v2_meaning_decision(packet, context)
    if not include_meaning:
        decision = {
            **decision,
            "meaning_included": False,
            "meaning_decision_reason": "Meaning disabled by explicit formatter configuration.",
        }
    verification = VERIFICATION_LABELS[packet["verification_status"]]
    sections = [f"Context — {context}"]
    if decision["meaning_included"]:
        sections.append(f"Meaning — {decision['meaning']}")
    if include_verification:
        sections.append(f"Verification — {verification}")
    if source:
        source_line = f"Source — {source['title']}"
        if source.get("url"):
            source_line += f"\n{source['url']}"
        sections.append(source_line)
    text = "\n\n".join(sections)
    weighted = x_weighted_length(text)
    if weighted > maximum_length or _v2_forbidden_style(text):
        return None
    if packet["verification_status"] in _V2_UNCERTAIN_STATUSES:
        variant = "compact_uncertain_wording"
    elif not decision["meaning_included"]:
        variant = "compact_without_redundant_meaning"
    elif not source or not source.get("url"):
        variant = "compact_no_public_url"
    else:
        variant = "compact_with_meaning"
    return {
        "quote_id": packet["quote_id"],
        "text": text,
        "character_count": weighted,
        "raw_character_count": len(text),
        "maximum_length": maximum_length,
        "historical_confidence": packet.get("research_confidence") or "unavailable",
        "meaning_included": bool(decision["meaning_included"]),
        "meaning_omitted": not bool(decision["meaning_included"]),
        "meaning_decision_reason": decision["meaning_decision_reason"],
        "meaning_rule_outputs": decision["rule_outputs"],
        "shortening_applied": False,
        "verification_label": verification if include_verification else None,
        "verification_omitted": not include_verification,
        "source": source,
        "source_class": classify_source(source),
        "source_omitted": not bool(source),
        "formatter_version": HISTORICAL_CONTEXT_FORMATTER_V2,
        "template_variant": variant,
        "weighted_character_count": weighted,
    }


def format_context_reply_v2(
    packet: dict[str, Any], *, maximum_length: int = DEFAULT_MAXIMUM_LENGTH,
    include_meaning: bool = True, include_source: bool = True,
    include_verification: bool = True, rendering_mode: str = PUBLIC_RENDERING_MODE,
) -> dict[str, Any] | None:
    """Render an audited context reply for public or internal consumption."""
    if type(maximum_length) is not int or not 120 <= maximum_length <= MAXIMUM_SUPPORTED_LENGTH:
        raise ValueError(f"maximum_length must be from 120 to {MAXIMUM_SUPPORTED_LENGTH}")
    if rendering_mode not in HISTORICAL_CONTEXT_RENDERING_MODES:
        raise ValueError("rendering_mode must be public or internal")
    if not isinstance(packet.get("_source_role_audit"), dict):
        return _format_context_reply_v2_legacy(
            packet,
            maximum_length=maximum_length,
            include_meaning=include_meaning,
            include_source=include_source,
            include_verification=include_verification,
        )
    public_sources = _audited_public_sources(packet) if include_source else []
    sources = (
        _audited_internal_sources(packet)
        if include_source and rendering_mode == INTERNAL_RENDERING_MODE
        else public_sources
    )
    source = select_primary_source(packet) if include_source else None
    audit = packet.get("_source_role_audit")
    supported_fields = None
    if isinstance(audit, dict):
        supported_fields = set(audit.get("public_context_supported_fields", []))
    context = _v2_context_sentence(
        packet,
        supported_fields,
        public_rendering=rendering_mode == PUBLIC_RENDERING_MODE,
    )
    decision = _v2_meaning_decision(packet, context)
    if not include_meaning:
        decision = {**decision, "meaning_included": False,
                    "meaning_decision_reason": "Meaning disabled by explicit formatter configuration."}
    confidence_dimensions = _audited_confidence(packet)
    verification = (
        _public_verification_label(packet, confidence_dimensions, public_sources)
        if rendering_mode == PUBLIC_RENDERING_MODE
        else _audited_verification_label(packet)
    )
    sections: list[str] = []
    if decision["meaning_included"]:
        sections.append(f"Meaning — {decision['meaning']}")
    if include_verification:
        sections.append(f"Verification — {verification}")
    if include_source:
        sections.extend(
            _internal_source_lines(sources)
            if rendering_mode == INTERNAL_RENDERING_MODE
            else _public_source_lines(sources)
        )
    generic_context_omitted = bool(
        rendering_mode == PUBLIC_RENDERING_MODE
        and context == _V2_GENERIC_CONTEXT
        and sections
    )
    if not generic_context_omitted:
        sections.insert(0, f"Context — {context}")
    if rendering_mode == INTERNAL_RENDERING_MODE:
        confidence_labels = (
            ("Attribution", "attribution"), ("wording", "wording"),
            ("source event", "source_event"), ("date", "date"),
            ("historical context", "historical_context"),
            ("interpretation", "interpretation"),
        )
        sections.append("Confidence — " + "; ".join(
            f"{label}: {confidence_dimensions[field]}" for label, field in confidence_labels
        ))
    text = "\n\n".join(sections)
    weighted = x_weighted_length(text)
    if weighted > maximum_length or _v2_forbidden_style(text):
        return None
    if generic_context_omitted:
        variant = "compact_generic_context_omitted"
    elif packet["verification_status"] in _V2_UNCERTAIN_STATUSES:
        variant = "compact_uncertain_wording"
    elif not decision["meaning_included"]:
        variant = "compact_without_redundant_meaning"
    elif not sources or not any(row.get("url") for row in sources):
        variant = "compact_no_public_url"
    else:
        variant = "compact_with_meaning"
    result = {
        "quote_id": packet["quote_id"], "text": text, "character_count": weighted,
        "raw_character_count": len(text), "maximum_length": maximum_length,
        "historical_confidence": _conservative_historical_confidence(confidence_dimensions),
        "confidence_dimensions": confidence_dimensions,
        "meaning_included": bool(decision["meaning_included"]),
        "meaning_omitted": not bool(decision["meaning_included"]),
        "meaning_decision_reason": decision["meaning_decision_reason"],
        "meaning_rule_outputs": decision["rule_outputs"],
        "shortening_applied": False,
        "verification_label": verification if include_verification else None,
        "verification_omitted": not include_verification,
        "source": source, "sources": sources,
        "source_class": classify_source(source), "source_omitted": not include_source,
        "source_role_audit_version": (
            audit.get("policy_version") if isinstance(audit, dict) else None
        ),
        "formatter_version": HISTORICAL_CONTEXT_FORMATTER_V5,
        "rendering_mode": rendering_mode,
        "template_variant": variant,
        "weighted_character_count": weighted,
    }
    if rendering_mode == INTERNAL_RENDERING_MODE:
        records, diagnostics = _internal_source_audit_payload(packet)
        result["internal_source_records"] = records
        result["source_identity_diagnostics"] = diagnostics
    return result


def format_context_reply_public(
    packet: dict[str, Any], *, maximum_length: int = DEFAULT_MAXIMUM_LENGTH,
    include_meaning: bool = True, include_source: bool = True,
    include_verification: bool = True,
) -> dict[str, Any] | None:
    """Render the compact public reply used for X posting."""
    return format_context_reply_v2(
        packet,
        maximum_length=maximum_length,
        include_meaning=include_meaning,
        include_source=include_source,
        include_verification=include_verification,
        rendering_mode=PUBLIC_RENDERING_MODE,
    )


def format_context_reply_internal(
    packet: dict[str, Any], *, maximum_length: int = DEFAULT_MAXIMUM_LENGTH,
    include_meaning: bool = True, include_source: bool = True,
    include_verification: bool = True,
) -> dict[str, Any] | None:
    """Render an internal view retaining the detailed confidence breakdown."""
    return format_context_reply_v2(
        packet,
        maximum_length=maximum_length,
        include_meaning=include_meaning,
        include_source=include_source,
        include_verification=include_verification,
        rendering_mode=INTERNAL_RENDERING_MODE,
    )


class HistoricalContextReplyStore:
    """Independent transactional state for confirmed context replies."""
    def __init__(
        self,
        history_path: Path,
        receipt_path: Path,
        *,
        mutation_authority_provider: (
            Callable[[str], TransactionMutationAuthority] | None
        ) = None,
        retirement_uncertainty_callback: Callable[[], None] | None = None,
        require_existing_history: bool = False,
    ):
        """Initialise the historical context reply store."""
        self.history_path = history_path
        self.receipt_path = receipt_path
        self._mutation_authority_provider = mutation_authority_provider
        self._retirement_uncertainty_callback = retirement_uncertainty_callback
        self._require_existing_history = bool(require_existing_history)

    def _mutation_authority(self, operation: str) -> TransactionMutationAuthority:
        if self._mutation_authority_provider is None:
            raise RuntimeError(
                f"{operation} requires an instance-lock mutation authority provider"
            )
        return self._mutation_authority_provider(operation)

    def history(self) -> dict[str, Any]:
        """Return the history."""
        try:
            os.lstat(self.history_path)
        except FileNotFoundError:
            if self._require_existing_history:
                raise RuntimeError(
                    "established historical context reply history is missing"
                )
            return {"schema_version": 1, "items": {}}
        except OSError as exc:
            raise RuntimeError(
                "historical context reply history namespace cannot be inspected"
            ) from exc
        history_bytes = self._read_stable_private_bytes(
            self.history_path,
            maximum=None,
            label="historical context reply history",
        )
        value = self._parse_history_json(history_bytes)
        if (
            not isinstance(value, dict)
            or set(value) != {"schema_version", "items"}
            or type(value.get("schema_version")) is not int
            or value.get("schema_version") != 1
            or not isinstance(value.get("items"), dict)
        ):
            raise RuntimeError("invalid context reply history")
        for parent_post_id, item in value["items"].items():
            if (
                not isinstance(item, dict)
                or type(item.get("parent_post_id")) is not str
                or item["parent_post_id"] != parent_post_id
            ):
                raise RuntimeError("invalid context reply history item")
            if item.get("status") == "completed":
                receipt = {key: value for key, value in item.items() if key != "status"}
                if not self._valid_receipt(receipt):
                    raise RuntimeError("invalid completed context reply history")
            elif item.get("status") == "failed":
                required_failed_fields = {
                    "parent_post_id",
                    "quote_id",
                    "reply_text",
                    "status",
                    "failure",
                    "attempt_count",
                    "updated_at",
                }
                source_proof_fields = {
                    "remote_outcome",
                    "source_receipt_sha256",
                    "source_receipt_attempt_number",
                }
                permitted_failed_fields = {
                    frozenset(required_failed_fields),
                    frozenset(required_failed_fields | {"formatter_metadata"}),
                    frozenset(required_failed_fields | source_proof_fields),
                    frozenset(
                        required_failed_fields
                        | source_proof_fields
                        | {"formatter_metadata"}
                    ),
                }
                if (
                    frozenset(item) not in permitted_failed_fields
                    or not re.fullmatch(r"\d{1,30}", parent_post_id)
                    or type(item.get("quote_id")) is not str
                    or not re.fullmatch(r"[0-9a-f]{64}", item["quote_id"])
                    or not isinstance(item.get("reply_text"), str)
                    or not item["reply_text"].strip()
                    or len(item["reply_text"]) > MAXIMUM_SUPPORTED_LENGTH
                    or type(item.get("attempt_count")) is not int
                    or item["attempt_count"] < 1
                    or type(item.get("failure")) is not str
                    or not item["failure"].strip()
                    or not self._valid_utc_timestamp(item.get("updated_at"))
                    or ("formatter_metadata" in item and not self._valid_formatter_metadata(item["formatter_metadata"]))
                    or (
                        bool(source_proof_fields & set(item))
                        and (
                            not source_proof_fields.issubset(item)
                            or item.get("remote_outcome") != "proved_non_success"
                            or type(item.get("source_receipt_sha256")) is not str
                            or not re.fullmatch(
                                r"[0-9a-f]{64}",
                                item["source_receipt_sha256"],
                            )
                            or type(item.get("source_receipt_attempt_number"))
                            is not int
                            or item["source_receipt_attempt_number"] < 1
                            or item["attempt_count"]
                            != item["source_receipt_attempt_number"]
                        )
                    )
                ):
                    raise RuntimeError("invalid failed context reply history")
            else:
                raise RuntimeError("invalid context reply history status")
        return value

    def _save_history(self, value: dict[str, Any]) -> None: atomic_write_json(self.history_path, value)

    def initialise_empty_history(self) -> dict[str, Any]:
        """Create the empty history authority for a genuinely new install."""

        try:
            os.lstat(self.history_path)
        except FileNotFoundError:
            pass
        except OSError as exc:
            raise RuntimeError(
                "historical context history namespace cannot be inspected"
            ) from exc
        else:
            raise FileExistsError(
                "refusing to initialise an existing historical context history"
            )
        value = {"schema_version": 1, "items": {}}
        self._save_history(value)
        return copy.deepcopy(value)

    @staticmethod
    def _parse_history_json(data: bytes) -> Any:
        """Parse one canonical history document without ambiguous JSON."""

        def reject_duplicate_names(
            pairs: list[tuple[str, Any]],
        ) -> dict[str, Any]:
            value: dict[str, Any] = {}
            for name, item in pairs:
                if name in value:
                    raise ValueError(
                        "duplicate historical-context history object name: "
                        f"{name}"
                    )
                value[name] = item
            return value

        def reject_nonfinite_constant(value: str) -> Any:
            raise ValueError(
                "non-finite historical-context history JSON constant: "
                f"{value}"
            )

        value = json.loads(
            data.decode("utf-8"),
            object_pairs_hook=reject_duplicate_names,
            parse_constant=reject_nonfinite_constant,
        )
        if canonical_json_bytes(value) != data:
            raise ValueError(
                "historical-context history is not canonical JSON"
            )
        return value

    @staticmethod
    def _parse_receipt_json(data: bytes) -> Any:
        """Parse receipt JSON without last-object-name-wins ambiguity."""

        def reject_duplicate_names(
            pairs: list[tuple[str, Any]],
        ) -> dict[str, Any]:
            value: dict[str, Any] = {}
            for name, item in pairs:
                if name in value:
                    raise ValueError(
                        f"duplicate historical-context receipt object name: {name}"
                    )
                value[name] = item
            return value

        def reject_nonfinite_constant(value: str) -> Any:
            raise ValueError(
                "non-finite historical-context receipt JSON constant: "
                f"{value}"
            )

        value = json.loads(
            data.decode("utf-8"),
            object_pairs_hook=reject_duplicate_names,
            parse_constant=reject_nonfinite_constant,
        )
        if canonical_json_bytes(value) != data:
            raise ValueError(
                "historical-context receipt is not canonical JSON"
            )
        return value

    @staticmethod
    def _read_stable_private_bytes(
        path: Path,
        *,
        maximum: int | None,
        label: str,
    ) -> bytes:
        """Read one stable private regular file without following links.

        ``maximum=None`` is reserved for the non-prunable reply-history
        authority.  That file is intentionally lifetime-unbounded because it
        supplies duplicate suppression; transaction receipts remain bounded.
        The observed size still bounds this individual read and all identity
        metadata is revalidated afterwards.
        """

        path = Path(path)
        before = os.lstat(path)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or before.st_uid != os.geteuid()
            or stat.S_IMODE(before.st_mode) != 0o600
            or (maximum is not None and before.st_size > maximum)
        ):
            raise RuntimeError(f"{label} has unsafe filesystem metadata")
        nofollow = getattr(os, "O_NOFOLLOW", 0)
        if not nofollow:
            raise RuntimeError(f"{label} inspection requires O_NOFOLLOW")
        try:
            descriptor = os.open(
                path,
                os.O_RDONLY | nofollow | getattr(os, "O_CLOEXEC", 0),
            )
        except FileNotFoundError as exc:
            raise RuntimeError(f"{label} disappeared after observation") from exc
        try:
            opened = os.fstat(descriptor)
            chunks: list[bytes] = []
            total = 0
            read_limit = before.st_size if maximum is None else maximum
            while total <= read_limit:
                chunk = os.read(
                    descriptor,
                    min(
                        65536,
                        read_limit + 1 - total,
                    ),
                )
                if not chunk:
                    break
                chunks.append(chunk)
                total += len(chunk)
            after_read = os.fstat(descriptor)
            try:
                after_path = os.lstat(path)
            except FileNotFoundError as exc:
                raise RuntimeError(f"{label} disappeared while it was read") from exc
        finally:
            os.close(descriptor)
        if (
            total > read_limit
            or total != before.st_size
            or not stat.S_ISREG(opened.st_mode)
            or opened.st_nlink != 1
            or opened.st_uid != os.geteuid()
            or stat.S_IMODE(opened.st_mode) != 0o600
            or not (
                opened.st_dev
                == before.st_dev
                == after_read.st_dev
                == after_path.st_dev
            )
            or not (
                opened.st_ino
                == before.st_ino
                == after_read.st_ino
                == after_path.st_ino
            )
            or not (
                opened.st_nlink
                == before.st_nlink
                == after_read.st_nlink
                == after_path.st_nlink
            )
            or not (
                opened.st_size
                == before.st_size
                == after_read.st_size
                == after_path.st_size
            )
            or not (
                opened.st_ctime_ns
                == before.st_ctime_ns
                == after_read.st_ctime_ns
                == after_path.st_ctime_ns
            )
            or not (
                opened.st_mtime_ns
                == before.st_mtime_ns
                == after_read.st_mtime_ns
                == after_path.st_mtime_ns
            )
            or after_path.st_uid != os.geteuid()
            or stat.S_IMODE(after_path.st_mode) != 0o600
        ):
            raise RuntimeError(f"{label} changed while it was read")
        return b"".join(chunks)

    @staticmethod
    def _valid_utc_timestamp(value: Any) -> bool:
        """Return whether *value* is one bounded canonical UTC timestamp."""

        if type(value) is not str or not value.endswith("Z") or len(value) > 64:
            return False
        try:
            parsed = datetime.fromisoformat(value[:-1] + "+00:00")
        except ValueError:
            return False
        return (
            parsed.tzinfo is not None
            and parsed.utcoffset() == timezone.utc.utcoffset(parsed)
            and parsed.isoformat().replace("+00:00", "Z") == value
        )

    @staticmethod
    def _read_stable_receipt_bytes(path: Path) -> bytes:
        """Read one owned, single-link ordinary receipt without following links."""

        return HistoricalContextReplyStore._read_stable_private_bytes(
            path,
            maximum=MAXIMUM_TRANSACTION_RECEIPT_BYTES,
            label="historical context reply receipt",
        )

    @classmethod
    def receipt_path_is_safe_regular(cls, path: Path) -> bool:
        """Return whether local reconciliation may inspect this exact path."""

        try:
            cls._read_stable_receipt_bytes(path)
        except (FileNotFoundError, OSError, RuntimeError):
            return False
        return True

    @classmethod
    def receipt_parent_for_safe_local_reconciliation(
        cls,
        path: Path,
    ) -> str | None:
        """Return the parent bound by one stable, valid transaction receipt."""

        try:
            data = cls._read_stable_receipt_bytes(path)
            receipt = cls._parse_receipt_json(data)
        except (
            FileNotFoundError,
            OSError,
            RuntimeError,
            UnicodeDecodeError,
            json.JSONDecodeError,
            ValueError,
        ):
            return None
        if not (
            cls._valid_sending_receipt(receipt)
            or cls._valid_receipt(receipt)
        ):
            return None
        return str(receipt["parent_post_id"])

    def _load_receipt_safely(self) -> tuple[Any, bytes] | None:
        """Load the receipt through its stable no-follow filesystem identity."""

        try:
            data = self._read_stable_receipt_bytes(self.receipt_path)
        except FileNotFoundError:
            return None
        try:
            return self._parse_receipt_json(data), data
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            raise RuntimeError("invalid context reply receipt JSON") from exc

    @staticmethod
    def _write_all(descriptor: int, data: bytes) -> None:
        """Write complete bytes or raise without treating a short write as success."""

        view = memoryview(data)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise OSError("short write while staging receipt tombstone")
            view = view[written:]

    def _retire_exact_receipt(self, expected_bytes: bytes) -> None:
        """Retire only the exact receipt through the shared crash protocol."""

        path = Path(self.receipt_path)
        retire_or_resume_exact_receipt(
            path,
            expected_bytes,
            mutation_authority=self._mutation_authority(
                "historical-context exact receipt retirement"
            ),
            on_retirement_uncertainty=self._retirement_uncertainty_callback,
        )

    @staticmethod
    def _valid_formatter_metadata(value: Any) -> bool:
        if not isinstance(value, dict):
            return False
        metadata_keys = frozenset(value)
        if metadata_keys not in {
            frozenset(_FORMATTER_METADATA_KEYS_V2),
            frozenset(_FORMATTER_METADATA_KEYS_V3),
            frozenset(_FORMATTER_METADATA_KEYS_V4),
            frozenset(_FORMATTER_METADATA_KEYS_V5),
        }:
            return False
        version = value.get("formatter_version")
        if metadata_keys == frozenset(_FORMATTER_METADATA_KEYS_V3) and (
            version != HISTORICAL_CONTEXT_FORMATTER_V3
        ):
            return False
        if metadata_keys == frozenset(_FORMATTER_METADATA_KEYS_V4) and version not in {
            HISTORICAL_CONTEXT_FORMATTER_V4,
            HISTORICAL_CONTEXT_FORMATTER_V5,
        }:
            return False
        if version in {
            HISTORICAL_CONTEXT_FORMATTER_V3,
            HISTORICAL_CONTEXT_FORMATTER_V4,
            HISTORICAL_CONTEXT_FORMATTER_V5,
        }:
            from historical_context_source_roles import POLICY_VERSION

            dimensions = value.get("confidence_dimensions")
            if (
                not isinstance(dimensions, dict)
                or set(dimensions) != {
                    "attribution", "wording", "source_event", "date",
                    "historical_context", "interpretation",
                }
                or any(item not in {"high", "medium", "low", "unknown"} for item in dimensions.values())
                or value.get("source_role_audit_version") not in (
                    _LEGACY_SOURCE_ROLE_AUDIT_VERSIONS | {POLICY_VERSION}
                )
            ):
                return False
        if version in {HISTORICAL_CONTEXT_FORMATTER_V4, HISTORICAL_CONTEXT_FORMATTER_V5} and (
            value.get("rendering_mode") not in HISTORICAL_CONTEXT_RENDERING_MODES
        ):
            return False
        return bool(
            isinstance(value, dict)
            and isinstance(value.get("formatter_version"), str)
            and value["formatter_version"].startswith("historical_context_reply_schema_v")
            and isinstance(value.get("template_variant"), str)
            and bool(value["template_variant"])
            and type(value.get("meaning_included")) is bool
            and isinstance(value.get("meaning_decision_reason"), str)
            and bool(value["meaning_decision_reason"])
            and type(value.get("raw_character_count")) is int
            and value["raw_character_count"] >= 1
            and type(value.get("weighted_character_count")) is int
            and value["weighted_character_count"] >= 1
            and (value.get("verification_label") is None or isinstance(value["verification_label"], str))
            and isinstance(value.get("source_class"), str)
            and value.get("historical_confidence") in {"high", "medium", "low", "unavailable"}
            and type(value.get("shortening_applied")) is bool
        )

    @staticmethod
    def _valid_receipt(receipt: Any) -> bool:
        if (not isinstance(receipt, dict) or type(receipt.get("schema_version")) is not int
                or receipt.get("schema_version") != 1):
            return False
        required = {
            "schema_version", "parent_post_id", "reply_post_id", "quote_id",
            "reply_text", "reply_epoch", "confirmed_at",
        }
        lifecycle = required | {"lifecycle_state", "started_at", "attempt_number"}
        with_metadata = lifecycle | {"formatter_metadata"}
        lineage = lifecycle | {"source_receipt_sha256"}
        lineage_with_metadata = with_metadata | {"source_receipt_sha256"}
        if set(receipt) not in (
            required,
            lifecycle,
            with_metadata,
            lineage,
            lineage_with_metadata,
        ):
            return False
        if "lifecycle_state" in receipt and receipt.get("lifecycle_state") != "confirmed":
            return False
        if "started_at" in receipt and (not isinstance(receipt["started_at"], str) or not receipt["started_at"].strip()):
            return False
        if "attempt_number" in receipt and (
            type(receipt["attempt_number"]) is not int or receipt["attempt_number"] < 1
        ):
            return False
        if "formatter_metadata" in receipt and not HistoricalContextReplyStore._valid_formatter_metadata(receipt["formatter_metadata"]):
            return False
        if (
            type(receipt.get("parent_post_id")) is not str
            or not re.fullmatch(r"\d{1,30}", receipt["parent_post_id"])
        ):
            return False
        if (
            type(receipt.get("reply_post_id")) is not str
            or not re.fullmatch(r"\d{1,30}", receipt["reply_post_id"])
        ):
            return False
        if (
            type(receipt.get("quote_id")) is not str
            or not re.fullmatch(r"[0-9a-f]{64}", receipt["quote_id"])
        ):
            return False
        if (
            not isinstance(receipt.get("reply_text"), str)
            or not receipt["reply_text"].strip()
            or len(receipt["reply_text"]) > MAXIMUM_SUPPORTED_LENGTH
        ):
            return False
        if type(receipt.get("reply_epoch")) is not int or receipt["reply_epoch"] < 0:
            return False
        if not (
            isinstance(receipt.get("confirmed_at"), str)
            and bool(receipt["confirmed_at"].strip())
        ):
            return False
        if "source_receipt_sha256" in receipt:
            try:
                source = HistoricalContextReplyStore.sending_receipt_from_confirmed(
                    receipt
                )
            except (TypeError, ValueError):
                return False
            if (
                not HistoricalContextReplyStore._valid_sending_receipt(source)
                or hashlib.sha256(canonical_json_bytes(source)).hexdigest()
                != receipt.get("source_receipt_sha256")
            ):
                return False
        return True

    @staticmethod
    def _valid_sending_receipt(receipt: Any) -> bool:
        required = {
            "schema_version", "lifecycle_state", "parent_post_id", "quote_id",
            "reply_text", "reply_epoch", "started_at", "attempt_number",
        }
        allowed = required | {"formatter_metadata"}
        return bool(
            isinstance(receipt, dict)
            and set(receipt) in (required, allowed)
            and type(receipt.get("schema_version")) is int
            and receipt.get("schema_version") == 1
            and receipt.get("lifecycle_state") == "sending"
            and type(receipt.get("parent_post_id")) is str
            and re.fullmatch(r"\d{1,30}", receipt["parent_post_id"])
            and type(receipt.get("quote_id")) is str
            and re.fullmatch(r"[0-9a-f]{64}", receipt["quote_id"])
            and isinstance(receipt.get("reply_text"), str)
            and receipt["reply_text"].strip()
            and len(receipt["reply_text"]) <= MAXIMUM_SUPPORTED_LENGTH
            and type(receipt.get("reply_epoch")) is int
            and MIN_CONFIRMATION_EPOCH
            <= receipt["reply_epoch"]
            <= MAX_CONFIRMATION_EPOCH
            and isinstance(receipt.get("started_at"), str)
            and receipt["started_at"].strip()
            and type(receipt.get("attempt_number")) is int
            and receipt["attempt_number"] >= 1
            and ("formatter_metadata" not in receipt or HistoricalContextReplyStore._valid_formatter_metadata(receipt["formatter_metadata"]))
        )

    @staticmethod
    def sending_receipt_from_confirmed(receipt: dict[str, Any]) -> dict[str, Any]:
        """Reconstruct the exact current pre-transport context receipt."""

        if (
            not isinstance(receipt, dict)
            or type(receipt.get("schema_version")) is not int
            or receipt.get("schema_version") != 1
            or receipt.get("lifecycle_state") != "confirmed"
            or type(receipt.get("source_receipt_sha256")) is not str
            or not re.fullmatch(
                r"[0-9a-f]{64}", receipt["source_receipt_sha256"]
            )
        ):
            raise ValueError(
                "confirmed historical-context receipt lacks exact source lineage"
            )
        source = copy.deepcopy(receipt)
        source.pop("reply_post_id", None)
        source.pop("confirmed_at", None)
        source.pop("source_receipt_sha256", None)
        source["lifecycle_state"] = "sending"
        return source

    @staticmethod
    def source_receipt_bytes_from_confirmed(receipt: dict[str, Any]) -> bytes:
        """Return the exact canonical source bytes anchored by a confirmed receipt."""

        source = HistoricalContextReplyStore.sending_receipt_from_confirmed(receipt)
        source_bytes = canonical_json_bytes(source)
        if (
            hashlib.sha256(source_bytes).hexdigest()
            != receipt.get("source_receipt_sha256")
        ):
            raise ValueError(
                "historical-context source-receipt lineage changed"
            )
        return source_bytes

    @staticmethod
    def _failed_history_matches_source_receipt(
        history_item: Any,
        receipt: dict[str, Any],
        receipt_bytes: bytes,
    ) -> bool:
        """Return whether one failure is bound to these exact source bytes."""

        return bool(
            isinstance(history_item, dict)
            and history_item.get("status") == "failed"
            and history_item.get("remote_outcome") == "proved_non_success"
            and history_item.get("parent_post_id") == receipt.get("parent_post_id")
            and history_item.get("quote_id") == receipt.get("quote_id")
            and history_item.get("reply_text") == receipt.get("reply_text")
            and history_item.get("source_receipt_attempt_number")
            == receipt.get("attempt_number")
            and history_item.get("attempt_count") == receipt.get("attempt_number")
            and history_item.get("source_receipt_sha256")
            == hashlib.sha256(receipt_bytes).hexdigest()
        )

    def ensure_proved_failure_history_from_outbox(
        self,
        context_reply: dict[str, Any],
    ) -> bool:
        """Recover a missing failure history from one exact outbox proof.

        This helper never infers an outcome from parent/quote identity or from
        independent attempt ordinals.  The failed outbox row must name the
        exact canonical sending-receipt bytes and the receipt's own attempt
        number.  A transport journal still present defeats the local
        non-success proof and remains fail closed.
        """

        if (
            not isinstance(context_reply, dict)
            or context_reply.get("state")
            not in {"context_reply_failed_retryable", "context_reply_failed_terminal"}
            or not isinstance(context_reply.get("failure"), dict)
        ):
            raise RuntimeError("outbox has no proved historical-context failure")
        failure = context_reply["failure"]
        if (
            failure.get("remote_outcome") != "proved_non_success"
            or type(failure.get("source_receipt_sha256")) is not str
            or not re.fullmatch(r"[0-9a-f]{64}", failure["source_receipt_sha256"])
            or type(failure.get("source_receipt_attempt_number")) is not int
            or failure["source_receipt_attempt_number"] < 1
        ):
            raise RuntimeError(
                "outbox failure lacks an exact proved-non-success source binding"
            )
        loaded = self._load_receipt_safely()
        if loaded is None or not self._valid_sending_receipt(loaded[0]):
            raise RuntimeError(
                "proved historical-context failure has no valid source receipt"
            )
        receipt, receipt_bytes = loaded
        if (
            context_reply.get("quote_id") != receipt.get("quote_id")
            or failure["source_receipt_sha256"]
            != hashlib.sha256(receipt_bytes).hexdigest()
            or failure["source_receipt_attempt_number"]
            != receipt.get("attempt_number")
            or transport_journal_is_blocking(
                journal_path_for_receipt(self.receipt_path)
            )
        ):
            raise RuntimeError(
                "outbox failure does not prove this exact untransmitted receipt"
            )
        history = self.history()
        parent_post_id = str(receipt["parent_post_id"])
        previous = history["items"].get(parent_post_id)
        if previous is not None:
            if self._failed_history_matches_source_receipt(
                previous,
                receipt,
                receipt_bytes,
            ):
                return False
            # The bounded history retains the latest source-store attempt for
            # one parent.  A newly proved exact non-success may legitimately
            # supersede the immediately preceding failed attempt.  Require a
            # strict same-identity, one-step progression; completed, gapped,
            # different-quote, or otherwise conflicting history stays closed.
            if not (
                previous.get("status") == "failed"
                and previous.get("parent_post_id") == parent_post_id
                and previous.get("quote_id") == receipt.get("quote_id")
                and previous.get("attempt_count")
                == int(receipt["attempt_number"]) - 1
            ):
                raise RuntimeError(
                    "historical-context history conflicts with the exact outbox proof"
                )
        try:
            updated_at = datetime.fromtimestamp(
                int(failure["failed_epoch"]),
                tz=timezone.utc,
            ).isoformat().replace("+00:00", "Z")
        except (OverflowError, OSError, ValueError) as exc:
            raise RuntimeError("outbox failure timestamp is not representable") from exc
        history["items"][parent_post_id] = {
            "parent_post_id": parent_post_id,
            "quote_id": str(receipt["quote_id"]),
            "reply_text": str(receipt["reply_text"]),
            "status": "failed",
            "failure": str(failure["error"]),
            "attempt_count": int(receipt["attempt_number"]),
            "updated_at": updated_at,
            "remote_outcome": "proved_non_success",
            "source_receipt_sha256": str(failure["source_receipt_sha256"]),
            "source_receipt_attempt_number": int(
                failure["source_receipt_attempt_number"]
            ),
            **(
                {"formatter_metadata": copy.deepcopy(receipt["formatter_metadata"])}
                if "formatter_metadata" in receipt
                else {}
            ),
        }
        self._save_history(history)
        return True

    def reconcile_receipt_disposition(
        self,
        *,
        retain_definite_failure_receipt: bool = False,
        preloaded_receipt: tuple[Any, bytes] | None | object = (
            _RECEIPT_NOT_PRELOADED
        ),
    ) -> str:
        """Reconcile one receipt and describe the exact durable outcome."""
        loaded = (
            self._load_receipt_safely()
            if preloaded_receipt is _RECEIPT_NOT_PRELOADED
            else preloaded_receipt
        )
        if loaded is None:
            return "absent"
        receipt, receipt_bytes = loaded
        if preloaded_receipt is not _RECEIPT_NOT_PRELOADED:
            current = self._load_receipt_safely()
            if (
                current is None
                or current[0] != receipt
                or current[1] != receipt_bytes
            ):
                raise RuntimeError(
                    "historical context reply receipt changed after its "
                    "preloaded authority was inspected"
                )
        if self._valid_sending_receipt(receipt):
            history = self.history()
            previous = history["items"].get(str(receipt["parent_post_id"]))
            if self._failed_history_matches_source_receipt(
                previous,
                receipt,
                receipt_bytes,
            ):
                if transport_journal_is_blocking(
                    journal_path_for_receipt(self.receipt_path)
                ):
                    raise AmbiguousContextReplyOutcome(
                        "historical context failure history conflicts with an "
                        "unresolved transport journal",
                        parent_post_id=str(receipt["parent_post_id"]),
                        reply_text=str(receipt["reply_text"]),
                    )
                if not retain_definite_failure_receipt:
                    self._retire_exact_receipt(receipt_bytes)
                return "definite_failure"
            raise AmbiguousContextReplyOutcome(
                "historical context reply was interrupted while sending; manual reconciliation required",
                parent_post_id=str(receipt["parent_post_id"]),
                reply_text=str(receipt["reply_text"]),
            )
        if not self._valid_receipt(receipt):
            raise RuntimeError("invalid historical context reply receipt")
        journal_path = journal_path_for_receipt(self.receipt_path)
        if transport_journal_is_blocking(journal_path):
            details = verify_confirmed_transport_source_lineage(
                receipt_path=self.receipt_path,
                expected_source_receipt_bytes=(
                    self.source_receipt_bytes_from_confirmed(receipt)
                ),
                lane="historical_context_reply",
                post_id=str(receipt["reply_post_id"]),
                validator_id=LANE_SOURCE_VALIDATOR_ID,
            )
            expected_confirmed_at = datetime.fromtimestamp(
                details.confirmation_epoch,
                tz=timezone.utc,
            ).isoformat().replace("+00:00", "Z")
            if receipt.get("confirmed_at") != expected_confirmed_at:
                raise RuntimeError(
                    "historical context confirmed time differs from its journal"
                )
        history = self.history()
        parent_post_id = str(receipt["parent_post_id"])
        previous = history["items"].get(parent_post_id)
        if previous and previous.get("status") == "completed":
            previous_receipt = {
                key: value
                for key, value in previous.items()
                if key != "status"
            }
            if previous_receipt != receipt:
                raise RuntimeError("historical context reply receipt conflicts with completed history")
        history["items"][parent_post_id] = {**receipt, "status": "completed"}
        self._save_history(history)
        if transport_journal_is_blocking(journal_path):
            prepare_exact_receipt_retirement(
                self.receipt_path,
                receipt_bytes,
                mutation_authority=self._mutation_authority(
                    "historical-context receipt retirement preparation"
                ),
            )
            retire_confirmed_transport_transaction(
                mutation_authority=self._mutation_authority(
                    "historical-context transport journal retirement"
                ),
                receipt_path=self.receipt_path,
                expected_confirmed_receipt=receipt,
                expected_source_receipt_bytes=(
                    self.source_receipt_bytes_from_confirmed(receipt)
                ),
                expected_current_receipt_bytes=receipt_bytes,
                source_retirement_prepared=True,
                lane="historical_context_reply",
                post_id=str(receipt["reply_post_id"]),
            )
        self._retire_exact_receipt(receipt_bytes)
        return "confirmed"

    def reconcile_receipt(self) -> bool:
        """Reconcile a receipt and retain the historical boolean API."""

        return self.reconcile_receipt_disposition() == "confirmed"

    def reconcile_confirmed_receipt_if_present(self) -> bool:
        """Reconcile only a proved-confirmed receipt, never a sending attempt.

        The daemon may call this before its global transaction barrier so that
        an already-confirmed local transaction can finish.  A sending receipt
        remains an ambiguity barrier and is deliberately left untouched.
        Invalid or unsafe receipt state still raises fail closed.
        """

        loaded = self._load_receipt_safely()
        if loaded is None:
            return False
        receipt, _receipt_bytes = loaded
        if self._valid_sending_receipt(receipt):
            return False
        if not self._valid_receipt(receipt):
            raise RuntimeError("invalid historical context reply receipt")
        return self.reconcile_receipt()

    def promote_sending_receipt_from_confirmed_transport(
        self,
        sending_receipt: dict[str, Any],
        *,
        reply_post_id: str,
        confirmation_epoch: int,
        require_confirmed_transport: bool = False,
    ) -> dict[str, Any]:
        """Bind a journal-confirmed reply to its exact surviving source receipt."""

        loaded = self._load_receipt_safely()
        if loaded is None:
            raise RuntimeError("historical context sending receipt disappeared")
        current, current_bytes = loaded
        expected_source_bytes = canonical_json_bytes(sending_receipt)
        if (
            current != sending_receipt
            or current_bytes != expected_source_bytes
            or not self._valid_sending_receipt(current)
        ):
            raise RuntimeError("historical context sending receipt changed")
        if not re.fullmatch(r"\d{1,30}", str(reply_post_id or "")):
            raise RuntimeError("historical context transport confirmation is invalid")
        if type(confirmation_epoch) is not int or confirmation_epoch < 0:
            raise RuntimeError("historical context confirmation epoch is invalid")
        confirmed = {
            **sending_receipt,
            "lifecycle_state": "confirmed",
            "reply_post_id": str(reply_post_id),
            "confirmed_at": datetime.fromtimestamp(
                confirmation_epoch,
                tz=timezone.utc,
            ).isoformat().replace("+00:00", "Z"),
            "source_receipt_sha256": hashlib.sha256(current_bytes).hexdigest(),
        }
        if not self._valid_receipt(confirmed):
            raise RuntimeError("historical context confirmed receipt is invalid")
        recovery = None
        if require_confirmed_transport:
            recovery = bind_confirmed_transport_source(
                journal_path=journal_path_for_receipt(self.receipt_path),
                receipt_path=self.receipt_path,
                validator_id=LANE_SOURCE_VALIDATOR_ID,
                validator=(
                    lambda lane, receipt, payload: bool(
                        lane == "historical_context_reply"
                        and self._valid_sending_receipt(receipt)
                        and set(payload) == {"text", "reply"}
                        and payload.get("text") == receipt.get("reply_text")
                        and payload.get("reply")
                        == {
                            "in_reply_to_tweet_id": str(
                                receipt.get("parent_post_id")
                            )
                        }
                    )
                ),
            )
            if (
                recovery.details.post_id != str(reply_post_id)
                or recovery.details.confirmation_epoch != confirmation_epoch
                or recovery.source_binding.receipt_document != sending_receipt
                or recovery.source_binding.receipt_bytes != expected_source_bytes
            ):
                raise RuntimeError(
                    "historical context confirmed transport/source lineage changed"
                )
        if recovery is not None:
            replace_bound_source_receipt(
                recovery.source_binding,
                canonical_json_bytes(confirmed),
                mutation_authority=self._mutation_authority(
                    "historical-context confirmed source receipt promotion"
                ),
            )
        else:
            atomic_write_json(self.receipt_path, confirmed)
        return confirmed

    def record_failure(
        self,
        parent_post_id: str,
        quote_id: str,
        text: str,
        error: BaseException,
        formatter_metadata: dict[str, Any] | None = None,
        *,
        source_receipt_sha256: str | None = None,
        source_receipt_attempt_number: int | None = None,
    ) -> None:
        """Record one definite failure, optionally bound to exact source bytes."""
        proof_present = (
            source_receipt_sha256 is not None
            or source_receipt_attempt_number is not None
        )
        if (
            type(parent_post_id) is not str
            or not re.fullmatch(r"\d{1,30}", parent_post_id)
            or type(quote_id) is not str
            or not re.fullmatch(r"[0-9a-f]{64}", quote_id)
            or type(text) is not str
            or not text.strip()
            or len(text) > MAXIMUM_SUPPORTED_LENGTH
            or (
                formatter_metadata is not None
                and not self._valid_formatter_metadata(formatter_metadata)
            )
            or (
                proof_present
                and (
                    type(source_receipt_sha256) is not str
                    or not re.fullmatch(r"[0-9a-f]{64}", source_receipt_sha256)
                    or type(source_receipt_attempt_number) is not int
                    or source_receipt_attempt_number < 1
                )
            )
        ):
            raise ValueError("invalid historical context failure record")
        failure = f"{type(error).__name__}: {error}".strip()
        history = self.history()
        previous = history["items"].get(str(parent_post_id), {})
        if (
            proof_present
            and previous.get("status") == "failed"
            and previous.get("source_receipt_sha256") == source_receipt_sha256
            and previous.get("source_receipt_attempt_number")
            == source_receipt_attempt_number
        ):
            return
        attempt_count = (
            int(source_receipt_attempt_number)
            if proof_present
            else int(previous.get("attempt_count", 0)) + 1
        )
        if proof_present and attempt_count != int(previous.get("attempt_count", 0)) + 1:
            raise RuntimeError(
                "historical context failure source attempt is not the next history attempt"
            )
        history["items"][str(parent_post_id)] = {"parent_post_id": str(parent_post_id), "quote_id": quote_id,
            "reply_text": text, "status": "failed", "failure": failure,
            "attempt_count": attempt_count, "updated_at": utc_now(),
            **(
                {
                    "remote_outcome": "proved_non_success",
                    "source_receipt_sha256": source_receipt_sha256,
                    "source_receipt_attempt_number": source_receipt_attempt_number,
                }
                if proof_present
                else {}
            ),
            **({"formatter_metadata": formatter_metadata} if formatter_metadata else {})}
        self._save_history(history)

    def post(self, *, parent_post_id: str, quote_id: str, reply_text: str,
             create_post: Callable[..., dict[str, Any]], now_epoch: Callable[[], int], dry_run: bool = False,
             formatter_metadata: dict[str, Any] | None = None,
             on_confirmed_receipt: Callable[[dict[str, Any], int], None] | None = None,
             on_source_receipt_published: Callable[[str, int], None] | None = None,
             on_remote_transaction_started: Callable[[], None] | None = None,
             on_definite_non_success: Callable[[BaseException], str] | None = None,
             remote_failure_is_definite_non_success: Callable[[BaseException], bool] | None = None,
             require_confirmed_transport: bool = False) -> dict[str, Any]:
        """Post and persist one historical-context reply transactionally."""
        if (
            type(parent_post_id) is not str
            or not re.fullmatch(r"\d{1,30}", parent_post_id)
            or type(quote_id) is not str
            or not re.fullmatch(r"[0-9a-f]{64}", quote_id)
            or not isinstance(reply_text, str)
            or not reply_text.strip()
            or len(reply_text) > MAXIMUM_SUPPORTED_LENGTH
        ):
            raise ValueError("invalid historical context reply request")
        if formatter_metadata is not None and not self._valid_formatter_metadata(formatter_metadata):
            raise ValueError("invalid historical context formatter metadata")
        if (
            on_source_receipt_published is not None
            and not callable(on_source_receipt_published)
        ):
            raise ValueError("invalid source receipt publication callback")
        if (
            on_remote_transaction_started is not None
            and not callable(on_remote_transaction_started)
        ):
            raise ValueError("invalid remote transaction phase callback")
        if (
            on_definite_non_success is not None
            and not callable(on_definite_non_success)
        ):
            raise ValueError("invalid definite non-success callback")
        if dry_run:
            return {"status": "dry_run", "parent_post_id": str(parent_post_id), "quote_id": quote_id,
                    "reply_text": reply_text, "character_count": len(reply_text)}
        if retirement_auxiliary_barrier_exists(self.receipt_path):
            raise AmbiguousContextReplyOutcome(
                "historical-context source-receipt retirement is incomplete",
                parent_post_id=str(parent_post_id),
                reply_text=reply_text,
            )
        self.reconcile_receipt()
        history = self.history()
        previous = history["items"].get(str(parent_post_id))
        if previous and previous.get("quote_id") != quote_id:
            raise RuntimeError("historical context reply quote identity conflicts with parent history")
        if previous and previous.get("status") == "completed": return {**previous, "status": "already_completed"}
        reply_epoch = int(now_epoch())
        if not (
            MIN_CONFIRMATION_EPOCH <= reply_epoch <= MAX_CONFIRMATION_EPOCH
        ):
            raise RuntimeError(
                "historical context pre-transport clock is outside the "
                "supported durable receipt range"
            )
        started_at = utc_now()
        sending = {
            "schema_version": 1,
            "lifecycle_state": "sending",
            "parent_post_id": str(parent_post_id),
            "quote_id": quote_id,
            "reply_text": reply_text,
            "reply_epoch": reply_epoch,
            "started_at": started_at,
            "attempt_number": int(previous.get("attempt_count", 0) if previous else 0) + 1,
            **({"formatter_metadata": formatter_metadata} if formatter_metadata else {}),
        }
        sending_bytes = canonical_json_bytes(sending)
        sending_sha256 = hashlib.sha256(sending_bytes).hexdigest()
        if len(sending_bytes) > MAXIMUM_TRANSACTION_RECEIPT_BYTES:
            raise ValueError("historical context sending receipt is too large")
        try:
            publish_exact_source_receipt_document(
                self.receipt_path,
                receipt_bytes=sending_bytes,
                mutation_authority=self._mutation_authority(
                    "historical-context sending receipt publication"
                ),
            )
        except (FileExistsError, BoundSourceReceiptTransitionError) as exc:
            raise AmbiguousContextReplyOutcome(
                "historical-context receipt appeared during publication; "
                "manual reconciliation is required",
                parent_post_id=str(parent_post_id),
                reply_text=reply_text,
            ) from exc

        if on_source_receipt_published is not None:
            try:
                on_source_receipt_published(
                    sending_sha256,
                    int(sending["attempt_number"]),
                )
            except Exception as binding_error:
                # The callback is before journal arming and before any remote
                # request.  Keep the exact source receipt as the durable local
                # recovery authority.  Beginning its retirement here creates
                # a crash state with neither terminal history nor a terminal
                # outbox outcome capable of authorising retirement on restart.
                raise DefiniteContextReplyLocalPersistenceError(
                    "could not bind the historical context source receipt; "
                    "the exact pre-transport receipt was retained",
                    parent_post_id=str(parent_post_id),
                    reply_text=reply_text,
                    source_receipt_sha256=sending_sha256,
                    source_receipt_attempt_number=int(sending["attempt_number"]),
                ) from binding_error

        def finish_definite_non_success(error: BaseException) -> dict[str, str]:
            durable_outbox_failure_state: str | None = None
            try:
                if on_definite_non_success is not None:
                    durable_outbox_failure_state = on_definite_non_success(error)
                    if (
                        type(durable_outbox_failure_state) is not str
                        or not durable_outbox_failure_state
                    ):
                        raise RuntimeError(
                            "definite non-success callback returned no durable state"
                        )
            except Exception as persistence_error:
                raise DefiniteContextReplyLocalPersistenceError(
                    "could not persist the context outbox failure; manual reconciliation required",
                    parent_post_id=str(parent_post_id),
                    reply_text=reply_text,
                    source_receipt_sha256=sending_sha256,
                    source_receipt_attempt_number=int(sending["attempt_number"]),
                    remote_error=error,
                ) from persistence_error
            try:
                self.record_failure(
                    parent_post_id,
                    quote_id,
                    reply_text,
                    error,
                    formatter_metadata,
                    source_receipt_sha256=sending_sha256,
                    source_receipt_attempt_number=int(sending["attempt_number"]),
                )
            except Exception as persistence_error:
                raise DefiniteContextReplyLocalPersistenceError(
                    "could not persist context reply failure history; manual reconciliation required",
                    parent_post_id=str(parent_post_id),
                    reply_text=reply_text,
                    source_receipt_sha256=sending_sha256,
                    source_receipt_attempt_number=int(sending["attempt_number"]),
                    remote_error=error,
                ) from persistence_error
            try:
                loaded = self._load_receipt_safely()
                if loaded is None or loaded[0] != sending:
                    raise RuntimeError(
                        "historical context sending receipt changed before retirement"
                    )
                self._retire_exact_receipt(loaded[1])
            except Exception as persistence_error:
                raise DefiniteContextReplyLocalPersistenceError(
                    "could not clear context reply sending record; manual reconciliation required",
                    parent_post_id=str(parent_post_id),
                    reply_text=reply_text,
                    source_receipt_sha256=sending_sha256,
                    source_receipt_attempt_number=int(sending["attempt_number"]),
                    remote_error=error,
                ) from persistence_error
            result: dict[str, Any] = {
                "status": "failed",
                "error": str(error),
                "error_type": type(error).__name__,
            }
            if durable_outbox_failure_state is not None:
                result["durable_outbox_failure_state"] = (
                    durable_outbox_failure_state
                )
            service = getattr(error, "service", None)
            status_code = getattr(error, "status_code", None)
            reset_epoch = getattr(error, "reset_epoch", None)
            if isinstance(service, str) and service:
                result["error_service"] = service
            if type(status_code) is int:
                result["error_status_code"] = status_code
            if type(reset_epoch) is int:
                result["error_reset_epoch"] = reset_epoch
            return result

        try:
            create_kwargs: dict[str, Any] = {
                "text": reply_text,
                "media_ids": None,
                "reply_to_id": str(parent_post_id),
                "made_with_ai": False,
                "prepared_historical_context_reply_receipt": sending,
            }
            if on_remote_transaction_started is not None:
                create_kwargs["on_remote_transaction_started"] = (
                    on_remote_transaction_started
                )
            response = create_post(
                **create_kwargs,
            )
        except BaseException as exc:
            definite = False
            if remote_failure_is_definite_non_success is not None:
                try:
                    definite = remote_failure_is_definite_non_success(exc) is True
                except Exception:
                    definite = False
            if definite:
                return finish_definite_non_success(exc)
            if not isinstance(exc, Exception):
                raise
            raise AmbiguousContextReplyOutcome(
                "remote context reply outcome is not proved; the durable sending "
                "receipt remains for manual reconciliation",
                parent_post_id=str(parent_post_id),
                reply_text=reply_text,
            ) from exc
        response_data = response.get("data") if isinstance(response, dict) else None
        reply_id = response_data.get("id") if isinstance(response_data, dict) else None
        if not re.fullmatch(r"\d{1,30}", str(reply_id or "")):
            raise AmbiguousContextReplyOutcome(
                "context reply may have been accepted but no valid post identity "
                "was returned; the durable sending receipt remains",
                parent_post_id=str(parent_post_id),
                reply_text=reply_text,
            )
        try:
            if require_confirmed_transport:
                details = verify_confirmed_transport_source_lineage(
                    receipt_path=self.receipt_path,
                    expected_source_receipt_bytes=sending_bytes,
                    lane="historical_context_reply",
                    post_id=str(reply_id),
                    validator_id=LANE_SOURCE_VALIDATOR_ID,
                )
                confirmation_epoch = details.confirmation_epoch
            else:
                confirmation_epoch = int(now_epoch())
            receipt = self.promote_sending_receipt_from_confirmed_transport(
                sending,
                reply_post_id=str(reply_id),
                confirmation_epoch=confirmation_epoch,
                require_confirmed_transport=require_confirmed_transport,
            )
        except Exception as exc:
            raise AmbiguousContextReplyOutcome(
                "could not persist confirmed reply receipt; manual reconciliation required",
                parent_post_id=str(parent_post_id),
                reply_text=reply_text,
            ) from exc
        if on_confirmed_receipt is not None:
            # The owning outbox must durably record the confirmed remote
            # identity before completed history or either transport/source
            # barrier is retired.  Propagate callback failure with all of
            # those barriers intact for restart reconciliation.
            on_confirmed_receipt(receipt, confirmation_epoch)
        self.reconcile_receipt()
        return {"status": "completed", **receipt}


def main(argv: list[str] | None = None) -> int:
    """Run the command-line entry point."""
    parser = argparse.ArgumentParser(description="Offline historical context reply formatter")
    parser.add_argument("--research-dir", type=Path, default=DEFAULT_RESEARCH_DIR)
    parser.add_argument("--quote-id"); parser.add_argument("--quote-text"); parser.add_argument("--maximum-length", type=int, default=DEFAULT_MAXIMUM_LENGTH)
    parser.add_argument(
        "--rendering-mode",
        choices=sorted(HISTORICAL_CONTEXT_RENDERING_MODES),
        default=INTERNAL_RENDERING_MODE,
        help="internal retains confidence detail; public matches the X reply",
    )
    args = parser.parse_args(argv); packets, unresolved = load_and_validate_corpus(
        args.research_dir,
        require_source_role_audit=True,
    )
    quote_id = args.quote_id or (quote_text_hash(args.quote_text) if args.quote_text else None)
    if not quote_id: parser.error("--quote-id or --quote-text is required")
    packet = packets.get(quote_id) if args.quote_id else packet_for_posted_quote(packets, unresolved, quote_id, args.quote_text)
    if (
        quote_id in unresolved
        or packet is None
        or not packet_is_attributed_to_margaret_thatcher(packet)
    ):
        raise SystemExit("no attribution-eligible completed canonical research packet; no reply")
    result = format_context_reply_v2(
        packet,
        maximum_length=args.maximum_length,
        rendering_mode=args.rendering_mode,
    )
    if result is None: raise SystemExit("canonical packet cannot produce a supported reply")
    print(result["text"])
    print(f"\nCharacter count: raw={result['raw_character_count']} x_weighted={result['character_count']}/{result['maximum_length']}")
    return 0


if __name__ == "__main__": raise SystemExit(main())
